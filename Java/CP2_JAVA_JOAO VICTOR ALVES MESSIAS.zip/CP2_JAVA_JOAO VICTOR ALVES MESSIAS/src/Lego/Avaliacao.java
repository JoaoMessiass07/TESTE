package Lego;

public class Avaliacao {
    private String usuario;
    private int avaliacao;
    private String comentario;

    public Avaliacao() {
    }

    public Avaliacao(String usuario, int avaliacao, String comentario) {
        this.usuario = usuario;
        this.avaliacao = avaliacao;
        this.comentario = comentario;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public int getAvaliacao() {
        return avaliacao;
    }

    public void setAvaliacao(int avaliacao) {
        this.avaliacao = avaliacao;
    }

    public String getComentario() {
        return comentario;
    }

    public void setComentario(String comentario) {
        this.comentario = comentario;
    }

    @Override
    public String toString() {
        return "Avaliacao{" +
                "usuario='" + usuario + '\'' +
                ", avaliacao=" + avaliacao +
                ", comentario='" + comentario + '\'' +
                '}';
    }
}

