package Lego;
public enum TEMA {
    ARQUITETURA,
    LEGO_BATMAN,
    CITY,
    CLASSIC,
    DC,
    DISNEY,
    STAR_WARS,
    NINJAGO,
}
