package Lego;

public class ImagemProduto {
    private String urlImagem;
    private double tamanhoArquvio;

    public ImagemProduto() {
    }

    public String getUrlImagem() {
        return urlImagem;
    }

    public void setUrlImagem(String urlImagem) {
        this.urlImagem = urlImagem;
    }

    public double getTamanhoArquvio() {
        return tamanhoArquvio;
    }

    public void setTamanhoArquvio(double tamanhoArquvio) {
        this.tamanhoArquvio = tamanhoArquvio;
    }

    @Override
    public String toString() {
        return "ImagemProduto{" +
                "urlImagem='" + urlImagem + '\'' +
                ", tamanhoArquvio=" + tamanhoArquvio +
                '}';
    }
}
