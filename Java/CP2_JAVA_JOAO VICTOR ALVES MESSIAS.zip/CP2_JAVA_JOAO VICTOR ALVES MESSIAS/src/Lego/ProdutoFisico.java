package Lego;

import java.util.List;

public class ProdutoFisico extends Produto{
    private int qnt_pecas;
    private int pontos_lego;
    private int qnt_itens;
    private double dimensao_x;
    private double dimensao_y;
    private double dimensao_z;
    private double peso;
    private STATUS status;

    public void exibirDetalhes(){

    }

    public ProdutoFisico(String nome, TEMA tema, String idade, double valor, String id_produto, ImagemProduto imagem, List<Avaliacao> avaliacao, String descricao, int qnt_pecas, int pontos_lego, int qnt_itens, double dimensao_x, double dimensao_y, double dimensao_z, double peso, STATUS status) {
        super(nome, tema, idade, valor, id_produto, imagem, avaliacao, descricao);
        this.qnt_pecas = qnt_pecas;
        this.pontos_lego = pontos_lego;
        this.qnt_itens = qnt_itens;
        this.dimensao_x = dimensao_x;
        this.dimensao_y = dimensao_y;
        this.dimensao_z = dimensao_z;
        this.peso = peso;
        this.status = status;
    }

    public int getQnt_pecas() {
        return qnt_pecas;
    }

    public void setQnt_pecas(int qnt_pecas) {
        this.qnt_pecas = qnt_pecas;
    }

    public int getPontos_lego() {
        return pontos_lego;
    }

    public void setPontos_lego(int pontos_lego) {
        this.pontos_lego = pontos_lego;
    }

    public int getQnt_itens() {
        return qnt_itens;
    }

    public void setQnt_itens(int qnt_itens) {
        this.qnt_itens = qnt_itens;
    }

    public double getDimensao_x() {
        return dimensao_x;
    }

    public void setDimensao_x(double dimensao_x) {
        this.dimensao_x = dimensao_x;
    }

    public double getDimensao_y() {
        return dimensao_y;
    }

    public void setDimensao_y(double dimensao_y) {
        this.dimensao_y = dimensao_y;
    }

    public double getDimensao_z() {
        return dimensao_z;
    }

    public void setDimensao_z(double dimensao_z) {
        this.dimensao_z = dimensao_z;
    }

    public double getPeso() {
        return peso;
    }

    public void setPeso(double peso) {
        this.peso = peso;
    }

    public STATUS getStatus() {
        return status;
    }

    public void setStatus(STATUS status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "ProdutoFisico{" +
                "qnt_pecas=" + qnt_pecas +
                ", pontos_lego=" + pontos_lego +
                ", qnt_itens=" + qnt_itens +
                ", dimensao_x=" + dimensao_x +
                ", dimensao_y=" + dimensao_y +
                ", dimensao_z=" + dimensao_z +
                ", peso=" + peso +
                ", status=" + status +
                "} " + super.toString();
    }
}


