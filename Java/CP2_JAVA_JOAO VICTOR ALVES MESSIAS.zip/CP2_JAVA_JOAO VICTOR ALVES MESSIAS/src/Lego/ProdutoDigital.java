package Lego;

import java.util.List;

public class ProdutoDigital extends Produto{
    private String tipo_arquivo;
    private String tamanho_arquivo;

    public void exibirDetalhes(){

    }

    public ProdutoDigital() {
    }

    public ProdutoDigital(String nome, TEMA tema, String idade, double valor, String id_produto, ImagemProduto imagem, List<Avaliacao> avaliacao, String descricao, String tipo_arquivo, String tamanho_arquivo) {
        super(nome, tema, idade, valor, id_produto, imagem, avaliacao, descricao);
        this.tipo_arquivo = tipo_arquivo;
        this.tamanho_arquivo = tamanho_arquivo;
    }

    public String getTipo_arquivo() {
        return tipo_arquivo;
    }

    public void setTipo_arquivo(String tipo_arquivo) {
        this.tipo_arquivo = tipo_arquivo;
    }

    public String getTamanho_arquivo() {
        return tamanho_arquivo;
    }

    public void setTamanho_arquivo(String tamanho_arquivo) {
        this.tamanho_arquivo = tamanho_arquivo;
    }

    @Override
    public String toString() {
        return "ProdutoDigital{" +
                "tipo_arquivo='" + tipo_arquivo + '\'' +
                ", tamanho_arquivo='" + tamanho_arquivo + '\'' +
                "} " + super.toString();
    }
}

