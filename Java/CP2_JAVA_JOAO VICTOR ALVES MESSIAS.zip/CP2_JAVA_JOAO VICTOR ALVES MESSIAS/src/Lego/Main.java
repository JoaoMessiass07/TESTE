package Lego;

import java.util.ArrayList;
import java.util.Arrays;

public class Main {
    public static void main(String[] args) {

    }
    public static void testeProduto(){
        var ProdutoDigital = new ProdutoDigital(
                "TIE Interceptor", TEMA.STAR_WARS, "15", 199.00, "123456", new ArrayList<>(Arrays.asList(
                new Avaliacao("user1", 8, "Bom produto"),
                new Avaliacao("user2", 5, "ok")
                )));

        //Considerei criar as classes abstrata produto, e as suas herdeiras produto digital e produtoFísico, assim distinguindo algumas caracteristicas
        //Assim também, criei classes como Avaliação, para adicionar avaliações do produto, tema, com variados temas de produtos.
        //Criei o encapsulamento dos objetos que iria trabalhar, e um método de exibir detalhes.
    }
};