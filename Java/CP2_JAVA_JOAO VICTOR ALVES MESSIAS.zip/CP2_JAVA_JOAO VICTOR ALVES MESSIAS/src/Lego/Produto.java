package Lego;

import java.util.List;

public class Produto {
    private String nome;
    private TEMA tema;
    private String idade;
    private double valor;
    private String id_produto;
    private ImagemProduto imagem;
    private List<Avaliacao> avaliacao;
    private String descricao;
    
    public Produto() {
    }

    public Produto(String nome, TEMA tema, String idade, double valor, String id_produto, ImagemProduto imagem, List<Avaliacao> avaliacao, String descricao) {
        this.nome = nome;
        this.tema = tema;
        this.idade = idade;
        this.valor = valor;
        this.id_produto = id_produto;
        this.imagem = imagem;
        this.avaliacao = avaliacao;
        this.descricao = descricao;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public TEMA getTema() {
        return tema;
    }

    public void setTema(TEMA tema) {
        this.tema = tema;
    }

    public String getIdade() {
        return idade;
    }

    public void setIdade(String idade) {
        this.idade = idade;
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }

    public String getId_produto() {
        return id_produto;
    }

    public void setId_produto(String id_produto) {
        this.id_produto = id_produto;
    }

    public ImagemProduto getImagem() {
        return imagem;
    }

    public void setImagem(ImagemProduto imagem) {
        this.imagem = imagem;
    }

    public List<Avaliacao> getAvaliacao() {
        return avaliacao;
    }

    public void setAvaliacao(List<Avaliacao> avaliacao) {
        this.avaliacao = avaliacao;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    @Override
    public String toString() {
        return "Produto{" +
                "nome='" + nome + '\'' +
                ", tema=" + tema +
                ", idade='" + idade + '\'' +
                ", valor=" + valor +
                ", id_produto='" + id_produto + '\'' +
                ", imagem=" + imagem +
                ", avaliacao=" + avaliacao +
                ", descricao='" + descricao + '\'' +
                '}';
    }
}
