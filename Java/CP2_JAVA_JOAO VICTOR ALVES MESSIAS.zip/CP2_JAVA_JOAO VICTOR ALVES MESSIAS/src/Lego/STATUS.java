package Lego;

public enum STATUS {
    DISPONIVEL,
    EM_BREVE,
    ESGOTADO,
    FORA_DE_LINHA
}
